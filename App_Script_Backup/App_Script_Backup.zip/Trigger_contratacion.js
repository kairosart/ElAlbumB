/************************************************************
 *  ARCHIVO DE TESTS COMPLETO — EL ÁLBUM B
 *  Permite probar TODO sin rellenar el formulario
 ************************************************************/


/************************************************************
 * 1. TEST — PRUEBA GRATIS (evento falso)
 ************************************************************/
function test_PruebaGratis() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName("PRUEBA GRATIS");

  const fila = 2; // cambia la fila que quieras probar

  const e = {
    range: sheet.getRange(fila, 1),
    namedValues: {
      "Dirección de correo electrónico": ["cliente@test.com"],
      "Estilo": ["Cinematic Drama"],
      "Foto": ["https://drive.google.com/file/d/1A0CbemkNty0uwmlofYbBEQJLtE0uhSm5/view?usp=sharing"]
    }
  };

  ejecutarPruebaGratis(e);
}



/************************************************************
 * 2. TEST — PACK EXPRESS (evento falso)
 ************************************************************/
function test_PackExpress() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName("PACK EXPRESS");

  const fila = 25;

  const e = {
    range: sheet.getRange(fila, 1),
    namedValues: {
      "Dirección de correo electrónico": "kairosart2007@gmail.com",
      "Nombre": "kairos"
    }
  };

  onFormSubmit(e);
}



/************************************************************
 * 3. TEST — Revelado Gemini directo (sin formulario)
 ************************************************************/
function test_GeminiDirecto() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName("PRUEBA GRATIS");

  const fila = 5;
  const email = "cliente@test.com";
  const estilo = "Cinematic Drama";
  const fileId = "ID_DE_FOTO_EN_DRIVE";

  ejecutarReveladoGemini(sheet, fila, email, estilo, fileId);
}



/************************************************************
 * 4. TEST — Webhook Stripe (simulación de pago completado)
 ************************************************************/
function test_WebhookStripe() {
  const e = {
    postData: {
      contents: JSON.stringify({
        type: "checkout.session.completed",
        data: {
          object: {
            customer_email: "cliente@test.com",
            client_reference_id: "PACK EXPRESS_FILA_10"
          }
        }
      })
    }
  };

  doPost(e);
}



/************************************************************
 * 5. TEST — Extraer ID de Drive
 ************************************************************/
function test_ExtraerID() {
  const url = "https://drive.google.com/file/d/1AbCdEfGhIjKlMnOpQrStUvWxYz123456/view?usp=sharing";
  const id = extraerIdDrive(url);
  Logger.log("ID extraído: " + id);
}



/************************************************************
 * 6. TEST — Crear carpeta y guardar archivo
 ************************************************************/
function test_CrearCarpetaYGuardar() {
  const carpetaRaiz = DriveApp.getFolderById(CARPETA_RAIZ_ID);
  const carpeta = carpetaRaiz.createFolder("test_cliente@test.com");

  const blob = Utilities.newBlob("Hola mundo", "text/plain", "test.txt");
  const archivo = carpeta.createFile(blob);

  Logger.log("Carpeta: " + carpeta.getUrl());
  Logger.log("Archivo: " + archivo.getUrl());
}



/************************************************************
 * 7. TEST — Limpieza automática
 ************************************************************/
function test_Limpieza() {
  limpiarCarpetasSeleccionadasConReporte();
}



/************************************************************
 * 8. TEST — Envío de email
 ************************************************************/
function test_Email() {
  GmailApp.sendEmail(
    "cliente@test.com",
    "Test Email",
    "Este es un email de prueba enviado desde Apps Script."
  );
}



/************************************************************
 * 9. TEST — Evento sin formulario (solo namedValues)
 ************************************************************/
function test_EventoSinFormulario() {
  const e = {
    namedValues: {
      "Dirección de correo electrónico": ["cliente@test.com"],
      "Nombre": ["Cliente Test"]
    }
  };

  onFormSubmit(e);
}



/************************************************************
 * 10. TEST — PRUEBA GRATIS con múltiples fotos
 ************************************************************/
function test_PruebaGratis_MultiplesFotos() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName("PRUEBA GRATIS");

  const fila = 6;

  const e = {
    range: sheet.getRange(fila, 1),
    namedValues: {
      "Dirección de correo electrónico": ["cliente@test.com"],
      "Estilo": ["Fine Art"],
      "Foto": [
        "https://drive.google.com/file/d/ID1/view",
        "https://drive.google.com/file/d/ID2/view",
        "https://drive.google.com/file/d/ID3/view"
      ]
    }
  };

  ejecutarPruebaGratis(e);
}
